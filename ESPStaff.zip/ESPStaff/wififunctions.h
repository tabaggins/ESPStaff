const char* ssid = "LEDstaff";
const char* passphrase = "sobrightigottawear";

ESP8266WebServer server(80);                        // start web server on port 80
WebSocketsServer webSocket = WebSocketsServer(81);  // start websockets server on port 81



String getContentType(String filename){
  if(server.hasArg("download")) return "application/octet-stream";
  else if(filename.endsWith(".htm")) return "text/html";
  else if(filename.endsWith(".html")) return "text/html";
  else if(filename.endsWith(".css")) return "text/css";
  else if(filename.endsWith(".js")) return "application/javascript";
  else if(filename.endsWith(".png")) return "image/png";
  else if(filename.endsWith(".gif")) return "image/gif";
  else if(filename.endsWith(".jpg")) return "image/jpeg";
  else if(filename.endsWith(".ico")) return "image/x-icon";
  else if(filename.endsWith(".xml")) return "text/xml";
  else if(filename.endsWith(".pdf")) return "application/x-pdf";
  else if(filename.endsWith(".zip")) return "application/x-zip";
  else if(filename.endsWith(".gz")) return "application/x-gzip";
  return "text/plain";
}

bool handleFileRead(String path){
  if(path.endsWith("/")) path += "index.htm";
  String contentType = getContentType(path);
  String pathWithGz = path + ".gz";
  if(SPIFFS.exists(pathWithGz) || SPIFFS.exists(path)){
    if(SPIFFS.exists(pathWithGz))
      path += ".gz";
    File file = SPIFFS.open(path, "r");
    size_t sent = server.streamFile(file, contentType);
    file.close();
    return true;
  }
  return false;
}


void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t payloadLength) {

  switch(type) {
    case WStype_DISCONNECTED:
      break;
    case WStype_CONNECTED:
      break;
    case WStype_TEXT:
      {
        String msg = String((char*)payload);
        if (msg.startsWith("lum:") && payloadLength >= 5) {
          int lum = (msg.substring(4)).toInt();
          FastLED.setBrightness(scale8(lum, MAXBRIGHTNESS));
        } else if (msg.startsWith("spd:") && payloadLength >= 5) {
          speedFactor = (msg.substring(4)).toInt();
        } else if (msg == "auto") {
          autoCycle = true;
        } else if (msg == "manual") {
          autoCycle = false;
        } else if (msg == "next") {
          if (++currentEffect >= numEffects) currentEffect = 0; // loop to start of effect list
          effectInit = false; // trigger effect initialization when new effect is selected
          enableFlashlight = false;
        } else if (msg == "prev") {
          if (--currentEffect < 0) currentEffect = numEffects - 1; // loop to end of effect list
          effectInit = false; // trigger effect initialization when new effect is selected
          enableFlashlight = false;
        } else if (msg == "flashlight") {
          effectInit = false;
          enableFlashlight = true;
        }
      }
      break;
    case WStype_BIN:
      break;
  }

}
